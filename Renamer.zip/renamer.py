import requests
import os
import yaml
import logging
import shutil
from pathlib import Path

# Importing stashapi.log as log for critical events
import stashapi.log as log

# Get the directory of the script
script_dir = Path(__file__).resolve().parent

# Configure logging for your script
log_file_path = script_dir / 'renamer.log'
logging.basicConfig(filename=log_file_path, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('renamer')

# GraphQL endpoint
endpoint = 'http://localhost:9999/graphql'  # Update with your endpoint

# GraphQL query to fetch all scenes
query_all_scenes = """
    query AllScenes {
        allScenes {
            id
            updated_at
        }
    }
"""

# Function to make GraphQL requests
def graphql_request(query, variables=None):
    data = {'query': query}
    if variables:
        data['variables'] = variables
    response = requests.post(endpoint, json=data)
    return response.json()

# Function to replace illegal characters in filenames
def replace_illegal_characters(filename):
    illegal_characters = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
    for char in illegal_characters:
        filename = filename.replace(char, '-')
    return filename

# Function to form the new filename based on scene details and user settings
def form_filename(scene_details, wrapper_styles, separator, key_order):
    filename_parts = []
    for key in key_order:
        if key == 'studio':
            studio_name = scene_details['studio']['name']
            if studio_name:
                if wrapper_styles.get('studio'):
                    filename_parts.append(f"{wrapper_styles['studio'][0]}{studio_name}{wrapper_styles['studio'][1]}")
                else:
                    filename_parts.append(studio_name)
        elif key == 'title':
            title = scene_details['title']
            if title:
                if wrapper_styles.get('title'):
                    filename_parts.append(f"{wrapper_styles['title'][0]}{title}{wrapper_styles['title'][1]}")
                else:
                    filename_parts.append(title)
        elif key == 'performers':
            performers = '-'.join([performer['name'] for performer in scene_details['performers']])
            if performers:
                if wrapper_styles.get('performers'):
                    filename_parts.append(f"{wrapper_styles['performers'][0]}{performers}{wrapper_styles['performers'][1]}")
                else:
                    filename_parts.append(performers)
        elif key == 'date':
            scene_date = scene_details['date']
            if scene_date:
                if wrapper_styles.get('date'):
                    filename_parts.append(f"{wrapper_styles['date'][0]}{scene_date}{wrapper_styles['date'][1]}")
                else:
                    filename_parts.append(scene_date)
    
    new_filename = separator.join(filename_parts).replace('--', '-')
    return replace_illegal_characters(new_filename)

def rename_scene(scene_id, wrapper_styles, separator, key_order, stash_directory, move_files=True):
    # Execute GraphQL query to find the scene by ID
    query_find_scene = """
        query FindScene($scene_id: ID!) {
            findScene(id: $scene_id) {
                id
                title
                date
                files {
                    path
                }
                studio {
                    name
                }
                performers {
                    name
                }
            }
        }
    """
    scene_result = graphql_request(query_find_scene, variables={"scene_id": scene_id})
    scene_details = scene_result.get('data', {}).get('findScene')
    if not scene_details:
        log.error(f"Scene with ID {scene_id} not found.")
        return
    
    # Form the new filename
    new_filename = form_filename(scene_details, wrapper_styles, separator, key_order)
    
    # Find the full file path of the scene being renamed
    original_file_path = scene_details['files'][0]['path']
    original_parent_directory = Path(original_file_path).parent
    
    # Initialize studio_directory variable
    studio_directory = None
    
    # Check if move_files is True and the parent directory is already named the same as the Studio key
    if move_files and original_parent_directory.name == scene_details['studio']['name']:
        log.info(f"File already in the proper directory for studio {scene_details['studio']['name']}. Skipping move.")
    else:
        # Move or rename the files associated with the scene
        for file in scene_details['files']:
            path = file['path']
            original_path = Path(path)
            new_path = original_parent_directory if not move_files else original_parent_directory / scene_details['studio']['name']
            new_path = new_path / (new_filename + original_path.suffix)
            
            try:
                if move_files:  # Check if files should be moved
                    if studio_directory is None:
                        studio_directory = original_parent_directory / scene_details['studio']['name']
                        studio_directory.mkdir(parents=True, exist_ok=True)
                    shutil.move(original_path, new_path)
                    log.info(f"Moved and renamed file: {path} -> {new_path}")
                    logger.info(f"Moved and renamed file: {path} -> {new_path}")  # Logging to the new logger as well
                else:
                    original_path.rename(new_path)
                    log.info(f"Renamed file: {path} -> {new_path}")
                    logger.info(f"Renamed file: {path} -> {new_path}")  # Logging to the new logger as well
            except FileNotFoundError:
                log.error(f"File not found: {path}. Skipping...")
                continue
            except OSError as e:
                log.error(f"Failed to move and rename file: {path}. Error: {e}")
                continue
    
    # Determine the metadata scan path based on the original parent directory
    metadata_scan_path = original_parent_directory
    
    # Perform metadata scan against the appropriate directory
    mutation_metadata_scan = """
        mutation MetadataScan($paths: [String]!) {
            metadataScan(input: { paths: $paths })
        }
    """
    
    # Format the directory path with double backslashes for Windows
    metadata_scan_path_windows = metadata_scan_path.resolve().as_posix()
    
    # Construct the metadata scan mutation with the paths included directly
    mutation_metadata_scan = """
        mutation {
            metadataScan(input: { paths: "%s" })
        }
    """ % metadata_scan_path_windows
    
    # Log the attempted metadata scan mutation
    logger.info(f"Attempting metadata scan mutation with path: {metadata_scan_path_windows}")
    logger.info(f"Mutation string: {mutation_metadata_scan}")
    
    # Execute the GraphQL mutation
    graphql_request(mutation_metadata_scan)

# Function to read settings from settings.yml
def read_settings():
    settings_file = script_dir / 'settings.yml'
    with open(settings_file, 'r') as file:
        settings = yaml.safe_load(file)
    return settings

# Execute the GraphQL query to fetch all scenes
scene_result = graphql_request(query_all_scenes)
all_scenes = scene_result.get('data', {}).get('allScenes', [])
if not all_scenes:
    log.error("No scenes found.")
    exit()

# Find the scene with the latest updated_at timestamp
latest_scene = max(all_scenes, key=lambda scene: scene['updated_at'])

# Extract the ID of the latest scene
latest_scene_id = latest_scene.get('id')

# Read settings from settings.yml
settings = read_settings()

# Extract wrapper styles, separator, and key order from settings
wrapper_styles = settings.get('wrapper_styles', {})
separator = settings.get('separator', '-')
key_order = settings.get('key_order', [])

# Read stash directory and move_files setting from settings.yml
stash_directory = settings.get('stash_directory', '')
move_files = settings.get('move_files', True)

# Rename the latest scene and trigger metadata scan
rename_scene(latest_scene_id, wrapper_styles, separator, key_order, stash_directory, move_files)
